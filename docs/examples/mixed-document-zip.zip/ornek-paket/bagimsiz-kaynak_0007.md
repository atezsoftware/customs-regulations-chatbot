# ZIP Bağımsız Yerel Test Genelgesi

Bu belge yalnızca yerel yazılım denemesi içindir ve arşivdeki diğer mevzuatın eki değildir.

## MADDE 1

Bu Genelge 1 Şubat 2027 tarihinde yürürlüğe girer. Başvurular elektronik ortamda alınır.
