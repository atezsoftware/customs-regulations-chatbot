# EK-2 — Süreler

MADDE 1 - Başvuru süresi otuz gündür.

[Ana mevzuat](../ana.md)
