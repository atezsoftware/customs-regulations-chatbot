# EK-1 — Başvuru Bilgileri

| Alan | Açıklama |
| --- | --- |
| Başvuran | Adı ve unvanı |
| Belge | Başvuru numarası |

[Ana mevzuat](../ana.md)
