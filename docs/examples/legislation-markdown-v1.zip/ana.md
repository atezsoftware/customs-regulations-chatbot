# Örnek Ana Mevzuat

MADDE 1 - Başvurunun esasları aşağıdaki eklerde yer alır.

[EK-1: Başvuru Bilgileri](ekler/ek-1.md)

[EK-2: Süreler](ekler/ek-2.md)
